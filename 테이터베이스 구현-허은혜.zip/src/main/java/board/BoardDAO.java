package board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class BoardDAO {

	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	
	// �����ͺ��̽� ����
	public BoardDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/bbs_db";
			String dbID = "root";
			String dbPassword = "root";
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Board> getList(){
		String SQL = "SELECT * FROM border ORDER BY docNum";                        
		ArrayList<Board> list = new ArrayList<Board>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();

			while(rs.next()) {
				Board board = new Board();
				board.setDocNum(rs.getInt(1));
				board.setDocTitle(rs.getString(2));
				board.setDocContent(rs.getString(3));
				board.setDocDate(rs.getString(4));
				list.add(board);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	//���� ��¥ ���ϱ�
	public String getDate() {
		String SQL = "SELECT NOW()";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}			
		}catch (Exception e) {
			e.printStackTrace();
			
		}
		return "";
	}
	
		
	//������ �� ������ȣ ���ϱ�
	public int getNext() {
		String SQL = "SELECT docNum FROM border ORDER BY docNum DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;//������ȣ
			}else {
				return 1;//���۹�ȣ
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//������ȣ
	}
		
	
	//�۾��� �޼ҵ�
	public int write(String docTitle, String docContent) {
		String SQL = "INSERT INTO border VALUES(?,?,?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, docTitle);
			pstmt.setString(3, docContent);
			pstmt.setString(4, getDate());
			pstmt.setInt(5, 1);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}
	
	public Board getDoc(int docNum) {
		String SQL = "SELECT * FROM border WHERE docNum = ?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1,docNum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Board board = new Board();
				board.setDocNum(rs.getInt(1));
				board.setDocTitle(rs.getString(2));
				board.setDocContent(rs.getString(3));
				board.setDocDate(rs.getString(4));
				return board;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
